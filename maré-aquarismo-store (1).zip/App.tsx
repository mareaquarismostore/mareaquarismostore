import React, { useState, useEffect } from 'react';
import { CATALOG_DATA, INITIAL_COUPONS, INITIAL_USERS } from './data';
import { Product, CartItem, User, TechLevel, Order, OrderStatus, Coupon } from './types';
import { ProductCard } from './components/ProductCard';
import { CartSidebar } from './components/CartSidebar';
import { AdminImportModal } from './components/AdminImportModal';
import { ClientDashboard } from './components/ClientDashboard';
import { AdminDashboard } from './components/AdminDashboard';
import { ToastContainer, ToastMessage } from './components/Toast';
import { ProductDetailsModal } from './components/ProductDetailsModal';
import { Search, ShoppingBag, User as UserIcon, LogOut, Menu, Filter, Leaf, Droplets, Ruler, Palette, ChevronLeft, ChevronRight, Settings, ShieldCheck, Home } from 'lucide-react';

const ITEMS_PER_PAGE = 20;

// Tipos de visualização da aplicação
type AppView = 'STORE' | 'CLIENT_DASHBOARD' | 'ADMIN_DASHBOARD';

// Enhanced Login/Register Modal Component
const LoginModal = ({ isOpen, onClose, onLogin, onRegister }: { 
  isOpen: boolean; 
  onClose: () => void; 
  onLogin: (email: string, pass: string) => void;
  onRegister: (name: string, email: string, pass: string) => void;
}) => {
  const [isRegistering, setIsRegistering] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (password.length < 3) {
      setError('A senha deve ter pelo menos 3 caracteres.');
      return;
    }

    if (isRegistering) {
      if (!name) {
        setError('Por favor, informe seu nome.');
        return;
      }
      onRegister(name, email, password);
    } else {
      onLogin(email, password);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="bg-white rounded-2xl shadow-2xl p-8 w-full max-w-sm animate-in fade-in zoom-in duration-200">
        
        {/* Toggle Tabs */}
        <div className="flex mb-6 bg-gray-100 p-1 rounded-lg">
          <button 
            className={`flex-1 py-2 text-sm font-bold rounded-md transition ${!isRegistering ? 'bg-white text-mare-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
            onClick={() => { setIsRegistering(false); setError(''); }}
          >
            Entrar
          </button>
          <button 
            className={`flex-1 py-2 text-sm font-bold rounded-md transition ${isRegistering ? 'bg-white text-mare-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
            onClick={() => { setIsRegistering(true); setError(''); }}
          >
            Criar Conta
          </button>
        </div>

        <h2 className="text-2xl font-bold text-mare-900 mb-2 text-center">
          {isRegistering ? 'Bem-vindo à Maré!' : 'Acesse sua conta'}
        </h2>
        <p className="text-gray-500 text-sm text-center mb-6">
          {isRegistering ? 'Preencha os dados para se cadastrar.' : 'Entre para gerenciar seus pedidos.'}
        </p>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          {isRegistering && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Nome Completo</label>
              <input 
                type="text" 
                required 
                value={name}
                onChange={e => setName(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-mare-500 outline-none"
                placeholder="Seu nome"
              />
            </div>
          )}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
            <input 
              type="email" 
              required 
              value={email}
              onChange={e => setEmail(e.target.value)}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-mare-500 outline-none"
              placeholder="seu@email.com"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Senha</label>
            <input 
              type="password" 
              required 
              value={password}
              onChange={e => setPassword(e.target.value)}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-mare-500 outline-none"
              placeholder="••••••••"
            />
          </div>
          
          {error && <p className="text-red-500 text-sm text-center bg-red-50 p-2 rounded">{error}</p>}

          <button type="submit" className="w-full bg-mare-900 text-white font-bold py-3 rounded-lg hover:bg-mare-800 transition shadow-lg shadow-mare-900/20">
            {isRegistering ? 'Cadastrar' : 'Entrar'}
          </button>
        </form>
        <button onClick={onClose} className="w-full mt-4 text-sm text-gray-500 hover:text-mare-900 underline">
          Cancelar
        </button>
      </div>
    </div>
  );
};

// Componente Galeria de Banner
const BannerCarousel = () => {
  const banners = [
    "https://picsum.photos/seed/aquarium1/1200/400",
    "https://picsum.photos/seed/aquarium2/1200/400",
    "https://picsum.photos/seed/aquarium3/1200/400"
  ];

  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent(prev => (prev + 1) % banners.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [banners.length]);

  const next = () => setCurrent((current + 1) % banners.length);
  const prev = () => setCurrent((current - 1 + banners.length) % banners.length);

  return (
    <div className="relative w-full h-48 md:h-72 lg:h-96 rounded-2xl overflow-hidden mb-8 shadow-lg group bg-gray-200">
      {banners.map((src, index) => (
        <div 
          key={index}
          className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${index === current ? 'opacity-100' : 'opacity-0'}`}
        >
          <img src={src} alt={`Banner Promocional ${index + 1}`} className="w-full h-full object-cover" />
        </div>
      ))}
      
      <button 
        onClick={prev} 
        className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/30 hover:bg-black/50 text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
      >
        <ChevronLeft size={24} />
      </button>
      
      <button 
        onClick={next} 
        className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/30 hover:bg-black/50 text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
      >
        <ChevronRight size={24} />
      </button>

      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
        {banners.map((_, idx) => (
          <button 
            key={idx}
            onClick={() => setCurrent(idx)}
            className={`h-2 rounded-full transition-all duration-300 shadow-sm ${idx === current ? 'bg-white w-8' : 'bg-white/50 w-2 hover:bg-white/80'}`}
          />
        ))}
      </div>
    </div>
  );
};

export default function App() {
  const [products, setProducts] = useState<Product[]>(CATALOG_DATA);
  const [coupons, setCoupons] = useState<Coupon[]>(() => {
    const saved = localStorage.getItem('mare_coupons');
    return saved ? JSON.parse(saved) : INITIAL_COUPONS;
  });
  
  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('mare_cart');
    return saved ? JSON.parse(saved) : [];
  });
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isAdminImportOpen, setIsAdminImportOpen] = useState(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  
  // App Logic State
  // User database simulation
  const [users, setUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem('mare_users_db');
    return saved ? JSON.parse(saved) : INITIAL_USERS;
  });

  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('mare_user');
    return saved ? JSON.parse(saved) : null;
  });
  const [activeView, setActiveView] = useState<AppView>('STORE');
  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem('mare_orders');
    return saved ? JSON.parse(saved) : [];
  });
  
  // Persist State
  useEffect(() => {
    localStorage.setItem('mare_cart', JSON.stringify(cartItems));
  }, [cartItems]);

  useEffect(() => {
    if (user) localStorage.setItem('mare_user', JSON.stringify(user));
    else localStorage.removeItem('mare_user');
  }, [user]);

  useEffect(() => {
    localStorage.setItem('mare_orders', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem('mare_coupons', JSON.stringify(coupons));
  }, [coupons]);

  useEffect(() => {
    localStorage.setItem('mare_users_db', JSON.stringify(users));
  }, [users]);

  // Pagination State
  const [currentPage, setCurrentPage] = useState(1);

  // Filters & Search
  const [searchTerm, setSearchTerm] = useState('');
  const [filterTech, setFilterTech] = useState<TechLevel | 'ALL'>('ALL');
  const [filterHeight, setFilterHeight] = useState<string>('ALL');
  const [filterColor, setFilterColor] = useState<string>('ALL');
  
  // Reset pagination when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, filterTech, filterHeight, filterColor]);

  // Toast Helper
  const addToast = (type: 'success' | 'error' | 'info', text: string) => {
    const id = Math.random().toString(36).substr(2, 9);
    setToasts(prev => [...prev, { id, type, text }]);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  // Auth Handlers
  const handleLogin = (email: string, pass: string) => {
    const foundUser = users.find(u => u.email.toLowerCase() === email.toLowerCase());
    
    if (foundUser && foundUser.password === pass) {
      setUser(foundUser);
      addToast('success', `Bem-vindo de volta, ${foundUser.name}!`);
      setIsLoginOpen(false);
      if (foundUser.isAdmin) {
        setActiveView('ADMIN_DASHBOARD');
      }
    } else {
      addToast('error', 'Email ou senha incorretos.');
    }
  };

  const handleRegister = (name: string, email: string, pass: string) => {
    const exists = users.some(u => u.email.toLowerCase() === email.toLowerCase());
    if (exists) {
      addToast('error', 'Este email já está cadastrado.');
      return;
    }

    const newUser: User = {
      name,
      email,
      password: pass,
      isAdmin: false
    };

    setUsers(prev => [...prev, newUser]);
    setUser(newUser);
    setIsLoginOpen(false);
    addToast('success', 'Conta criada com sucesso!');
  };

  const handleLogout = () => {
    setUser(null);
    setActiveView('STORE');
    addToast('info', 'Você saiu da conta.');
  };

  // Handlers
  const handleAddToCart = (product: Product) => {
    setCartItems(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => 
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { ...product, quantity: 1 }];
    });
    addToast('success', `${product.name} adicionado ao carrinho!`);
    setIsCartOpen(true);
  };

  const handleUpdateQuantity = (id: string, delta: number) => {
    setCartItems(prev => prev.map(item => {
      if (item.id === id) {
        return { ...item, quantity: Math.max(1, item.quantity + delta) };
      }
      return item;
    }));
  };

  const handleRemoveItem = (id: string) => {
    setCartItems(prev => prev.filter(item => item.id !== id));
    addToast('info', 'Item removido do carrinho.');
  };

  const handleCatalogUpdate = (newProducts: Product[]) => {
    setProducts(newProducts);
    setCurrentPage(1); 
    addToast('success', 'Catálogo atualizado com sucesso!');
  };

  const handleDeleteProduct = (id: string) => {
    if (window.confirm('Tem certeza que deseja excluir este produto?')) {
      setProducts(prev => prev.filter(p => p.id !== id));
      addToast('success', 'Produto removido.');
    }
  };

  const handleAddCoupon = (newCoupon: Coupon) => {
    if (coupons.some(c => c.code === newCoupon.code)) {
        addToast('error', 'Já existe um cupom com este código.');
        return;
    }
    setCoupons(prev => [...prev, newCoupon]);
    addToast('success', 'Cupom criado com sucesso!');
  };

  const handleDeleteCoupon = (code: string) => {
    if (window.confirm('Excluir este cupom permanentemente?')) {
        setCoupons(prev => prev.filter(c => c.code !== code));
        addToast('info', 'Cupom excluído.');
    }
  };

  // Checkout Handler
  const handleCheckout = (total: number, items: CartItem[], method: 'WHATSAPP' | 'MERCADO_PAGO') => {
    const newOrder: Order = {
      id: Math.random().toString(36).substr(2, 9).toUpperCase(),
      date: new Date().toLocaleDateString('pt-BR'),
      items: [...items],
      total: total,
      status: OrderStatus.PENDING,
      paymentMethod: method
    };

    setOrders(prev => [newOrder, ...prev]);
    setCartItems([]);
    setIsCartOpen(false);
    
    if (method === 'WHATSAPP') {
        addToast('success', 'Mensagem enviada! Verifique seu WhatsApp.');
    } else {
        addToast('info', 'Aguardando pagamento no Mercado Pago.');
    }
    
    if (user) {
        setActiveView('CLIENT_DASHBOARD');
    }
  };

  // Filter Logic for Store
  const filteredProducts = products.filter(p => {
    // Only apply filters in STORE view logic
    const searchLower = searchTerm.toLowerCase();
    const matchesSearch = 
      p.name.toLowerCase().includes(searchLower) || 
      p.id.toLowerCase().includes(searchLower) ||
      p.color.toLowerCase().includes(searchLower) ||
      p.height.toLowerCase().includes(searchLower) ||
      p.techLevel.toLowerCase().includes(searchLower);
    
    const matchesTech = filterTech === 'ALL' || p.techLevel === filterTech;
    const matchesHeight = filterHeight === 'ALL' || p.height === filterHeight;
    const matchesColor = filterColor === 'ALL' || p.color === filterColor;
    
    return matchesSearch && matchesTech && matchesHeight && matchesColor;
  });

  // Pagination Logic
  const totalPages = Math.ceil(filteredProducts.length / ITEMS_PER_PAGE);
  const indexOfLastItem = currentPage * ITEMS_PER_PAGE;
  const indexOfFirstItem = indexOfLastItem - ITEMS_PER_PAGE;
  const currentItems = filteredProducts.slice(indexOfFirstItem, indexOfLastItem);

  const paginate = (pageNumber: number) => {
    setCurrentPage(pageNumber);
    window.scrollTo({ top: 400, behavior: 'smooth' }); 
  };

  const cartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);
  const uniqueHeights = Array.from(new Set(products.map(p => p.height))).sort();
  const uniqueColors = Array.from(new Set(products.map(p => p.color))).sort();

  return (
    <div className="min-h-screen flex flex-col font-sans relative">
      <ToastContainer toasts={toasts} removeToast={removeToast} />

      {/* Navbar */}
      <header className="sticky top-0 z-40 bg-mare-900 text-white shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between gap-4">
            {/* Logo */}
            <button onClick={() => setActiveView('STORE')} className="flex items-center gap-2 hover:opacity-90 transition">
              <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center text-mare-900 font-bold text-xl border-2 border-blue-400">
                M
              </div>
              <div className="hidden md:block leading-none text-left">
                <h1 className="text-xl font-bold tracking-wide">MARÉ</h1>
                <span className="text-xs text-blue-200 tracking-[0.2em] uppercase">Aquarismo</span>
              </div>
            </button>

            {/* Global Search - Context Aware */}
            <div className="hidden md:flex flex-1 max-w-lg mx-8 relative">
              <input 
                type="text" 
                placeholder={
                  activeView === 'STORE' ? "Busque por plantas, cor, tipo..." :
                  activeView === 'ADMIN_DASHBOARD' ? "Filtrar produtos na tabela..." :
                  "Buscar em seus pedidos..."
                }
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full py-2 pl-10 pr-4 rounded-full bg-mare-800 border border-mare-500 text-white placeholder-blue-300 focus:bg-white focus:text-mare-900 focus:outline-none transition-colors"
              />
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-blue-300" size={18} />
            </div>

            {/* Actions */}
            <div className="flex items-center gap-4">
              {user ? (
                <div className="flex items-center gap-3">
                   {/* Navigation Links based on user type */}
                   {user.isAdmin ? (
                      <button 
                        onClick={() => setActiveView('ADMIN_DASHBOARD')}
                        className={`text-sm font-semibold hover:text-blue-300 transition ${activeView === 'ADMIN_DASHBOARD' ? 'text-blue-300 underline underline-offset-4' : ''}`}
                      >
                        Dashboard
                      </button>
                   ) : (
                      <button 
                        onClick={() => setActiveView('CLIENT_DASHBOARD')}
                         className={`text-sm font-semibold hover:text-blue-300 transition ${activeView === 'CLIENT_DASHBOARD' ? 'text-blue-300 underline underline-offset-4' : ''}`}
                      >
                        Meus Pedidos
                      </button>
                   )}
                   
                   {activeView !== 'STORE' && (
                      <button onClick={() => setActiveView('STORE')} className="p-2 hover:bg-mare-800 rounded-full text-blue-300 hover:text-white" title="Ir para Loja">
                        <Home size={20} />
                      </button>
                   )}

                  <div className="h-6 w-px bg-mare-800 mx-1"></div>
                  
                  <button onClick={handleLogout} className="flex items-center gap-1 text-xs text-red-300 hover:text-white transition">
                    <LogOut size={14} />
                    Sair
                  </button>
                </div>
              ) : (
                <button 
                  onClick={() => setIsLoginOpen(true)}
                  className="flex items-center gap-2 hover:bg-mare-800 px-3 py-2 rounded-lg transition"
                >
                  <UserIcon size={20} />
                  <span className="text-sm hidden sm:block">Login</span>
                </button>
              )}

              {/* Cart is always accessible */}
              <button 
                onClick={() => setIsCartOpen(true)}
                className="relative p-2 hover:bg-mare-800 rounded-full transition group"
              >
                <ShoppingBag size={24} className="group-hover:text-blue-200" />
                {cartCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] font-bold w-5 h-5 flex items-center justify-center rounded-full border-2 border-mare-900">
                    {cartCount}
                  </span>
                )}
              </button>
            </div>
          </div>
          
          {/* Mobile Search */}
          <div className="md:hidden mt-4 relative">
             <input 
                type="text" 
                placeholder="Buscar..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full py-2 pl-10 pr-4 rounded-lg bg-mare-800 text-white placeholder-blue-300 focus:outline-none"
              />
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-blue-300" size={18} />
          </div>
        </div>
      </header>

      {/* Main Content Router */}
      <main className="flex-grow container mx-auto px-4 py-8">
        
        {/* VIEW: STORE */}
        {activeView === 'STORE' && (
          <div className="animate-in fade-in duration-300">
            <BannerCarousel />

            {/* Filters */}
            <div className="bg-white p-5 rounded-xl border border-gray-200 shadow-sm mb-8">
              <div className="flex items-center gap-2 mb-4 pb-3 border-b border-gray-100">
                <Filter size={18} className="text-mare-500" />
                <span className="font-bold text-gray-800 text-lg">Filtrar Plantas</span>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-2">
                   <div className="flex items-center gap-2 text-gray-600 mb-1">
                     <Droplets size={16} />
                     <label className="text-xs font-bold uppercase tracking-wide">Nível de Exigência</label>
                   </div>
                   <select 
                      value={filterTech} 
                      onChange={(e) => setFilterTech(e.target.value as any)}
                      className="w-full p-2.5 bg-gray-50 border border-gray-300 rounded-lg text-sm text-gray-700 outline-none"
                    >
                      <option value="ALL">Todas</option>
                      <option value={TechLevel.HIGH}>High Tech</option>
                      <option value={TechLevel.LOW}>Low Tech</option>
                    </select>
                </div>
                <div className="space-y-2">
                   <div className="flex items-center gap-2 text-gray-600 mb-1">
                     <Ruler size={16} />
                     <label className="text-xs font-bold uppercase tracking-wide">Altura</label>
                   </div>
                   <select 
                      value={filterHeight} 
                      onChange={(e) => setFilterHeight(e.target.value)}
                      className="w-full p-2.5 bg-gray-50 border border-gray-300 rounded-lg text-sm text-gray-700 outline-none"
                    >
                      <option value="ALL">Qualquer altura</option>
                      {uniqueHeights.map(h => <option key={h} value={h}>{h}</option>)}
                    </select>
                </div>
                <div className="space-y-2">
                   <div className="flex items-center gap-2 text-gray-600 mb-1">
                     <Palette size={16} />
                     <label className="text-xs font-bold uppercase tracking-wide">Cor</label>
                   </div>
                   <select 
                      value={filterColor} 
                      onChange={(e) => setFilterColor(e.target.value)}
                      className="w-full p-2.5 bg-gray-50 border border-gray-300 rounded-lg text-sm text-gray-700 outline-none"
                    >
                      <option value="ALL">Qualquer cor</option>
                      {uniqueColors.map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                </div>
              </div>
            </div>

            {/* Results */}
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-bold text-gray-800 flex items-center gap-2">
                <Leaf className="text-green-600" />
                Resultados <span className="text-sm font-normal text-gray-500">
                  ({filteredProducts.length} itens {filteredProducts.length > ITEMS_PER_PAGE && `- Página ${currentPage}`})
                </span>
              </h3>
              {(filterTech !== 'ALL' || filterHeight !== 'ALL' || filterColor !== 'ALL' || searchTerm !== '') && (
                <button 
                  onClick={() => { setFilterTech('ALL'); setFilterHeight('ALL'); setFilterColor('ALL'); setSearchTerm(''); }}
                  className="text-xs text-red-500 font-semibold hover:underline"
                >
                  Limpar Filtros
                </button>
              )}
            </div>

            {/* Grid */}
            {currentItems.length > 0 ? (
              <>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 mb-8">
                  {currentItems.map(product => (
                    <ProductCard 
                      key={product.id} 
                      product={product} 
                      onAddToCart={handleAddToCart} 
                      onOpenDetails={setSelectedProduct}
                    />
                  ))}
                </div>

                {/* Pagination Controls */}
                {totalPages > 1 && (
                  <div className="flex justify-center items-center gap-2 py-4">
                    <button 
                      onClick={() => paginate(currentPage - 1)}
                      disabled={currentPage === 1}
                      className="p-2 rounded-lg border border-gray-300 hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed transition"
                    >
                      <ChevronLeft size={20} />
                    </button>
                    
                    <div className="flex gap-1">
                      {Array.from({ length: totalPages }, (_, i) => i + 1).map(number => (
                        <button
                          key={number}
                          onClick={() => paginate(number)}
                          className={`w-10 h-10 rounded-lg font-semibold transition ${
                            currentPage === number 
                              ? 'bg-mare-900 text-white shadow-md' 
                              : 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-50'
                          }`}
                        >
                          {number}
                        </button>
                      ))}
                    </div>

                    <button 
                      onClick={() => paginate(currentPage + 1)}
                      disabled={currentPage === totalPages}
                      className="p-2 rounded-lg border border-gray-300 hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed transition"
                    >
                      <ChevronRight size={20} />
                    </button>
                  </div>
                )}
                
                <p className="text-center text-xs text-gray-400 mt-2">
                  Mostrando {indexOfFirstItem + 1} - {Math.min(indexOfLastItem, filteredProducts.length)} de {filteredProducts.length} produtos
                </p>
              </>
            ) : (
              <div className="text-center py-20 bg-white rounded-xl shadow-sm border border-dashed border-gray-300">
                <Leaf size={48} className="mx-auto text-gray-300 mb-4" />
                <h3 className="text-lg font-medium text-gray-600">Nenhuma planta encontrada</h3>
                <p className="text-gray-400 text-sm">Tente ajustar seus filtros de busca.</p>
              </div>
            )}
          </div>
        )}

        {/* VIEW: CLIENT DASHBOARD */}
        {activeView === 'CLIENT_DASHBOARD' && user && (
          <ClientDashboard 
            user={user} 
            orders={orders} 
            searchTerm={searchTerm} 
          />
        )}

        {/* VIEW: ADMIN DASHBOARD */}
        {activeView === 'ADMIN_DASHBOARD' && user?.isAdmin && (
          <AdminDashboard 
            products={products}
            coupons={coupons}
            searchTerm={searchTerm}
            onOpenImport={() => setIsAdminImportOpen(true)}
            onDeleteProduct={handleDeleteProduct}
            onAddCoupon={handleAddCoupon}
            onDeleteCoupon={handleDeleteCoupon}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-mare-900 text-blue-200 py-8 border-t border-mare-800 relative">
        <div className="container mx-auto px-4 grid md:grid-cols-3 gap-8 text-sm">
          <div>
            <h4 className="text-white font-bold mb-4 uppercase tracking-wider">Maré Aquarismo</h4>
            <p>Av. Osório de Paiva, 1448<br/>Parangaba - Fortaleza/CE</p>
          </div>
          <div>
            <h4 className="text-white font-bold mb-4 uppercase tracking-wider">Contato</h4>
            <p>(85) 98797.7235</p>
            <p>mareaquarismo@gmail.com</p>
          </div>
          <div>
            <h4 className="text-white font-bold mb-4 uppercase tracking-wider">Sistema</h4>
            <p>V 1.2.0 - React Store</p>
            {user?.isAdmin && (
               <button onClick={() => setActiveView('ADMIN_DASHBOARD')} className="text-blue-400 hover:text-white mt-2 underline">
                 Acessar Painel Admin
               </button>
            )}
          </div>
        </div>
        <div className="text-center mt-8 pt-8 border-t border-mare-800 text-xs text-blue-400 relative">
          © {new Date().getFullYear()} Maré Aquarismo.
        </div>
      </footer>

      {/* Overlays */}
      <CartSidebar 
        isOpen={isCartOpen} 
        onClose={() => setIsCartOpen(false)} 
        items={cartItems}
        coupons={coupons}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onCheckout={handleCheckout}
      />
      
      <LoginModal 
        isOpen={isLoginOpen} 
        onClose={() => setIsLoginOpen(false)}
        onLogin={handleLogin}
        onRegister={handleRegister}
      />

      <AdminImportModal 
        isOpen={isAdminImportOpen}
        onClose={() => setIsAdminImportOpen(false)}
        onUpdateData={handleCatalogUpdate}
      />

      <ProductDetailsModal
        product={selectedProduct}
        isOpen={!!selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={handleAddToCart}
      />
    </div>
  );
}