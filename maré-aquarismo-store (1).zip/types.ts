export enum TechLevel {
  HIGH = 'HIGH TECH',
  LOW = 'LOW TECH',
  EMERGENTE = 'EMERGENTE'
}

export enum ProductStatus {
  AVAILABLE = 'DISPONÍVEL',
  OUT_OF_STOCK = 'ESGOTADO',
  FEW_LEFT = 'PEQUENO'
}

export interface Product {
  id: string; // The Code from PDF (A01, B02, etc.)
  name: string; // Variety
  price: number;
  stock?: number;
  status: ProductStatus;
  techLevel: TechLevel;
  color: string;
  height: string;
  image?: string;
  
  // New Admin Fields
  costPrice?: number;
  internalId?: string;
  barcode?: string;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface User {
  name: string;
  email: string;
  password?: string; // Added for auth simulation
  isAdmin?: boolean;
}

export enum OrderStatus {
  PENDING = 'Pendente',
  PAID = 'Pago',
  SHIPPED = 'Enviado',
  DELIVERED = 'Entregue'
}

export interface Order {
  id: string;
  date: string;
  items: CartItem[];
  total: number;
  status: OrderStatus;
  paymentMethod?: 'WHATSAPP' | 'MERCADO_PAGO';
}

export interface Coupon {
  code: string;
  type: 'PERCENTAGE' | 'FIXED';
  value: number;
  active: boolean;
}