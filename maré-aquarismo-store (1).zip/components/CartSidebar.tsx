import React, { useState } from 'react';
import { CartItem, Coupon } from '../types';
import { X, Trash2, Minus, Plus, CreditCard, Tag, MessageCircle, Wallet } from 'lucide-react';

interface CartSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  coupons: Coupon[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  onCheckout: (total: number, items: CartItem[], method: 'WHATSAPP' | 'MERCADO_PAGO') => void;
}

export const CartSidebar: React.FC<CartSidebarProps> = ({ 
  isOpen, 
  onClose, 
  items, 
  coupons,
  onUpdateQuantity, 
  onRemoveItem,
  onCheckout
}) => {
  const [couponCode, setCouponCode] = useState('');
  const [activeCoupon, setActiveCoupon] = useState<Coupon | null>(null);
  const [couponMessage, setCouponMessage] = useState<{type: 'success' | 'error', text: string} | null>(null);

  const subtotal = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  
  let discount = 0;
  if (activeCoupon) {
    if (activeCoupon.type === 'PERCENTAGE') {
      discount = subtotal * (activeCoupon.value / 100);
    } else {
      discount = activeCoupon.value;
    }
  }
  
  const total = Math.max(0, subtotal - discount);

  const handleApplyCoupon = () => {
    const found = coupons.find(c => c.code.toUpperCase() === couponCode.toUpperCase() && c.active);
    
    if (found) {
      setActiveCoupon(found);
      const msg = found.type === 'PERCENTAGE' 
        ? `Cupom de ${found.value}% aplicado!` 
        : `Desconto de R$ ${found.value.toFixed(2)} aplicado!`;
      setCouponMessage({ type: 'success', text: msg });
    } else {
      setActiveCoupon(null);
      setCouponMessage({ type: 'error', text: 'Cupom inválido ou expirado.' });
    }
  };

  const handleWhatsAppCheckout = () => {
    const header = `Olá, gostaria de finalizar o seguinte pedido na Maré Aquarismo:\n\n`;
    const itemList = items.map(item => `- ${item.quantity}x ${item.name} (${item.id}) - R$ ${(item.price * item.quantity).toFixed(2)}`).join('\n');
    const totals = `\n\nSubtotal: R$ ${subtotal.toFixed(2)}\nDesconto: R$ ${discount.toFixed(2)}\n*Total: R$ ${total.toFixed(2)}*`;
    const footer = `\n\nAguardo confirmação de disponibilidade e dados para pagamento.`;
    
    const message = encodeURIComponent(header + itemList + totals + footer);
    const phoneNumber = "5585987977235"; 
    
    window.open(`https://wa.me/${phoneNumber}?text=${message}`, '_blank');
    onCheckout(total, items, 'WHATSAPP');
  };

  const handleMercadoPagoCheckout = () => {
    // Simulação de redirecionamento
    alert("Redirecionando para o Mercado Pago...");
    onCheckout(total, items, 'MERCADO_PAGO');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm transition-opacity" onClick={onClose} />
      
      {/* Sidebar Panel */}
      <div className="relative w-full max-w-md bg-white h-full shadow-2xl flex flex-col transform transition-transform duration-300">
        
        {/* Header */}
        <div className="p-4 bg-mare-900 text-white flex justify-between items-center shadow-md">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <CreditCard size={20} />
            Seu Carrinho
          </h2>
          <button onClick={onClose} className="hover:bg-mare-800 p-1 rounded transition-colors">
            <X size={24} />
          </button>
        </div>

        {/* Items List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {items.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-gray-400 space-y-4">
              <div className="bg-gray-100 p-6 rounded-full">
                <Trash2 size={48} />
              </div>
              <p className="text-lg font-medium">Seu carrinho está vazio.</p>
              <button onClick={onClose} className="text-mare-500 font-semibold hover:underline">
                Voltar às compras
              </button>
            </div>
          ) : (
            items.map((item) => (
              <div key={item.id} className="flex gap-4 bg-white border border-gray-100 rounded-lg p-3 shadow-sm">
                <img src={item.image} alt={item.name} className="w-20 h-20 object-cover rounded-md bg-gray-100" />
                <div className="flex-1 flex flex-col justify-between">
                  <div>
                    <h4 className="font-semibold text-gray-800 text-sm line-clamp-2">{item.name}</h4>
                    <p className="text-xs text-gray-500">{item.id}</p>
                  </div>
                  <div className="flex justify-between items-end">
                    <span className="font-bold text-mare-900">R$ {item.price.toFixed(2).replace('.',',')}</span>
                    
                    <div className="flex items-center gap-2 bg-gray-50 rounded-lg border border-gray-200 p-1">
                      <button 
                        onClick={() => onUpdateQuantity(item.id, -1)}
                        className="p-1 hover:bg-gray-200 rounded text-gray-600 disabled:opacity-50"
                        disabled={item.quantity <= 1}
                      >
                        <Minus size={14} />
                      </button>
                      <span className="text-sm font-semibold w-6 text-center">{item.quantity}</span>
                      <button 
                         onClick={() => onUpdateQuantity(item.id, 1)}
                         className="p-1 hover:bg-gray-200 rounded text-gray-600"
                      >
                        <Plus size={14} />
                      </button>
                    </div>
                  </div>
                </div>
                <button 
                  onClick={() => onRemoveItem(item.id)}
                  className="text-gray-400 hover:text-red-500 self-start p-1"
                >
                  <X size={16} />
                </button>
              </div>
            ))
          )}
        </div>

        {/* Footer / Checkout */}
        {items.length > 0 && (
          <div className="p-6 bg-gray-50 border-t border-gray-200 space-y-4">
            
            {/* Coupon Section */}
            <div className="space-y-2">
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Tag className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                  <input 
                    type="text" 
                    placeholder="Cupom de desconto"
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-mare-500 outline-none uppercase"
                  />
                </div>
                <button 
                  onClick={handleApplyCoupon}
                  className="bg-gray-800 text-white px-4 py-2 text-sm font-semibold rounded-lg hover:bg-gray-700 transition"
                >
                  Aplicar
                </button>
              </div>
              {couponMessage && (
                <p className={`text-xs ${couponMessage.type === 'success' ? 'text-green-600' : 'text-red-500'}`}>
                  {couponMessage.text}
                </p>
              )}
            </div>

            {/* Totals */}
            <div className="space-y-2 pt-2 border-t border-dashed border-gray-300">
              <div className="flex justify-between text-sm text-gray-600">
                <span>Subtotal</span>
                <span>R$ {subtotal.toFixed(2).replace('.', ',')}</span>
              </div>
              {discount > 0 && (
                <div className="flex justify-between text-sm text-green-600">
                  <span>Desconto</span>
                  <span>- R$ {discount.toFixed(2).replace('.', ',')}</span>
                </div>
              )}
              <div className="flex justify-between text-lg font-bold text-gray-900 pt-2">
                <span>Total</span>
                <span>R$ {total.toFixed(2).replace('.', ',')}</span>
              </div>
            </div>

            {/* Checkout Options */}
            <div className="space-y-3 pt-2">
                <p className="text-xs font-bold text-gray-500 uppercase tracking-wide text-center">Escolha como pagar</p>
                
                <button 
                  onClick={handleWhatsAppCheckout}
                  className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-4 rounded-xl shadow-lg transform transition active:scale-95 flex items-center justify-center gap-2"
                >
                  <MessageCircle size={20} />
                  <span>Finalizar no WhatsApp</span>
                </button>

                <button 
                  onClick={handleMercadoPagoCheckout}
                  className="w-full bg-mercado-500 hover:bg-mercado-600 text-white font-bold py-3 px-4 rounded-xl shadow-lg transform transition active:scale-95 flex items-center justify-center gap-2"
                >
                  <Wallet size={20} />
                  <span>Pagar com Mercado Pago</span>
                </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};