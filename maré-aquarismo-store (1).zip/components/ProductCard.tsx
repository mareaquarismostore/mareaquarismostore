import React from 'react';
import { Product, ProductStatus, TechLevel } from '../types';
import { ShoppingCart, Leaf } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
  onOpenDetails?: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onAddToCart, onOpenDetails }) => {
  const isOutOfStock = product.status === ProductStatus.OUT_OF_STOCK;

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-all duration-300 flex flex-col h-full border border-gray-100 group/card">
      <div 
        className="relative h-48 overflow-hidden bg-gray-100 cursor-pointer"
        onClick={() => onOpenDetails && onOpenDetails(product)}
      >
        <img 
          src={product.image} 
          alt={product.name} 
          className={`w-full h-full object-cover transition-transform duration-500 group-hover/card:scale-110 ${isOutOfStock ? 'grayscale opacity-70' : ''}`}
        />
        
        {/* Overlay on hover indicating clickability */}
        <div className="absolute inset-0 bg-black/0 group-hover/card:bg-black/10 transition-colors" />

        {isOutOfStock && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/40">
            <span className="bg-red-600 text-white px-3 py-1 text-sm font-bold rounded-full uppercase tracking-wider">
              Esgotado
            </span>
          </div>
        )}
        <div className="absolute top-2 left-2 flex gap-1 flex-wrap">
            <span className={`text-[10px] font-bold px-2 py-1 rounded-full text-white ${product.techLevel === TechLevel.HIGH ? 'bg-orange-500' : 'bg-green-600'}`}>
                {product.techLevel}
            </span>
            {product.stock && product.stock > 0 && (
                <span className="text-[10px] font-bold px-2 py-1 rounded-full bg-blue-600 text-white">
                   {product.stock} em estoque
                </span>
            )}
        </div>
      </div>

      <div className="p-4 flex flex-col flex-grow">
        <div className="flex justify-between items-start mb-2">
            <span className="text-xs text-gray-500 font-mono bg-gray-100 px-1 rounded">{product.id}</span>
        </div>
        <h3 
          className="text-gray-800 font-semibold text-lg leading-tight mb-2 flex-grow hover:text-mare-600 cursor-pointer transition-colors"
          onClick={() => onOpenDetails && onOpenDetails(product)}
        >
          {product.name}
        </h3>
        
        <div className="flex flex-col gap-1 text-xs text-gray-500 mb-4">
            <div className="flex items-center gap-1">
                <Leaf size={12} />
                <span>Altura: {product.height}</span>
            </div>
            <div className="flex items-center gap-1">
                <div className="w-3 h-3 rounded-full border border-gray-300" style={{backgroundColor: product.color.includes('Vermelh') ? '#ef4444' : product.color.includes('Rox') ? '#9333ea' : product.color.includes('Rosa') ? '#ec4899' : '#22c55e'}}></div>
                <span>Cor: {product.color}</span>
            </div>
        </div>

        <div className="flex items-center justify-between mt-auto pt-4 border-t border-gray-100">
          <div className="flex flex-col">
            <span className="text-xs text-gray-500">Preço Unit.</span>
            <span className="text-xl font-bold text-mare-900">
              R$ {product.price.toFixed(2).replace('.', ',')}
            </span>
          </div>

          <button
            onClick={(e) => {
              e.stopPropagation();
              onAddToCart(product);
            }}
            disabled={isOutOfStock}
            className={`p-2 rounded-full transition-colors shadow-sm ${
              isOutOfStock 
                ? 'bg-gray-200 text-gray-400 cursor-not-allowed' 
                : 'bg-mare-900 text-white hover:bg-mare-800 active:scale-95'
            }`}
            aria-label={isOutOfStock ? "Produto esgotado" : "Adicionar ao carrinho"}
          >
            <ShoppingCart size={20} />
          </button>
        </div>
      </div>
    </div>
  );
};