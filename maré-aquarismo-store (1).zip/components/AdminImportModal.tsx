import React, { useState, useRef } from 'react';
import { X, Upload, FileText, FileSpreadsheet, CheckCircle, AlertCircle, Loader2, Database, HelpCircle } from 'lucide-react';
import { Product, ProductStatus, TechLevel } from '../types';
import * as XLSX from 'xlsx';

interface AdminImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUpdateData: (newProducts: Product[]) => void;
}

export const AdminImportModal: React.FC<AdminImportModalProps> = ({ isOpen, onClose, onUpdateData }) => {
  const [activeTab, setActiveTab] = useState<'file' | 'json'>('file');
  const [dragActive, setDragActive] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [status, setStatus] = useState<'idle' | 'processing' | 'success' | 'error'>('idle');
  const [importStats, setImportStats] = useState({ total: 0, new: 0 });
  const [jsonInput, setJsonInput] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setFile(e.dataTransfer.files[0]);
      setStatus('idle');
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setStatus('idle');
    }
  };

  // Helper para gerar dados aleatórios realistas (Simulação PDF)
  const generateMockProducts = (count: number): Product[] => {
    const prefixes = ['Rotala', 'Ludwigia', 'Hygrophila', 'Cryptocoryne', 'Echinodorus', 'Bucephalandra', 'Anubias'];
    const suffixes = ['Rotundifolia', 'Palustris', 'Polysperma', 'Wendtii', 'Amazonicus', 'Kedagang', 'Nana'];
    
    return Array.from({ length: count }).map((_, i) => {
      const isHighTech = Math.random() > 0.5;
      const statusRoll = Math.random();
      
      return {
        id: `IMP${Math.floor(Math.random() * 10000)}`,
        name: `${prefixes[Math.floor(Math.random() * prefixes.length)]} ${suffixes[Math.floor(Math.random() * suffixes.length)]} (Lote ${new Date().getDate()})`,
        price: parseFloat((15 + Math.random() * 80).toFixed(2)),
        status: statusRoll > 0.8 ? ProductStatus.OUT_OF_STOCK : statusRoll > 0.6 ? ProductStatus.FEW_LEFT : ProductStatus.AVAILABLE,
        techLevel: isHighTech ? TechLevel.HIGH : TechLevel.LOW,
        color: Math.random() > 0.5 ? 'Verde' : 'Vermelha',
        height: Math.random() > 0.5 ? 'Média' : 'Alta',
        stock: Math.floor(Math.random() * 20),
        image: `https://picsum.photos/seed/${Math.random()}/300/300`
      };
    });
  };

  const processFile = async () => {
    if (!file) return;
    setStatus('processing');

    try {
      if (file.name.endsWith('.xlsx') || file.name.endsWith('.xls') || file.name.endsWith('.csv')) {
        // Leitura REAL do Excel
        const reader = new FileReader();
        reader.onload = (e) => {
          try {
            const data = new Uint8Array(e.target?.result as ArrayBuffer);
            const workbook = XLSX.read(data, { type: 'array' });
            const firstSheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[firstSheetName];
            const jsonData: any[] = XLSX.utils.sheet_to_json(worksheet);

            // Mapeamento inteligente de colunas
            const newProducts: Product[] = jsonData.map((row, index) => ({
              id: row['Código'] || row['ID'] || row['Code'] || `XLS${index}`,
              name: row['Nome'] || row['Produto'] || row['Name'] || 'Produto Sem Nome',
              price: parseFloat(row['Preço'] || row['Price'] || row['Valor'] || '0'),
              status: ProductStatus.AVAILABLE, // Default
              techLevel: (row['Tipo'] && row['Tipo'].toString().toUpperCase().includes('LOW')) ? TechLevel.LOW : TechLevel.HIGH,
              color: row['Cor'] || 'Verde',
              height: row['Altura'] || 'Média',
              stock: parseInt(row['Estoque'] || '10'),
              image: `https://picsum.photos/seed/${row['Código'] || index}/300/300` // Placeholder se não houver imagem
            }));

            if (newProducts.length > 0) {
              onUpdateData(newProducts);
              setImportStats({ total: newProducts.length, new: newProducts.length });
              setStatus('success');
            } else {
              alert("Não foi possível encontrar produtos válidos na planilha. Verifique os cabeçalhos (Nome, Preço, Código).");
              setStatus('error');
            }
          } catch (err) {
            console.error(err);
            setStatus('error');
          }
        };
        reader.readAsArrayBuffer(file);

      } else {
        // Simulação para PDF (Gerando dados novos para parecer uma importação real)
        setTimeout(() => {
          // Geramos 50 itens para garantir que a paginação (20 por página) apareça
          const newProducts = generateMockProducts(50); 
          onUpdateData(newProducts);
          setImportStats({ total: 50, new: 50 });
          setStatus('success');
        }, 2000);
      }
    } catch (error) {
      console.error(error);
      setStatus('error');
    }
  };

  const handleJsonSubmit = () => {
    try {
      const parsed = JSON.parse(jsonInput);
      if (Array.isArray(parsed)) {
        onUpdateData(parsed);
        setImportStats({ total: parsed.length, new: parsed.length });
        setStatus('success');
      } else {
        alert("O JSON deve ser uma lista (array) de produtos.");
      }
    } catch (e) {
      alert("JSON Inválido. Verifique a formatação.");
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-gray-900 text-white p-6 flex justify-between items-center">
          <div>
            <h2 className="text-xl font-bold flex items-center gap-2">
              <Database className="text-blue-400" />
              Painel Administrativo
            </h2>
            <p className="text-gray-400 text-sm">Atualização de Catálogo</p>
          </div>
          <button onClick={onClose} className="hover:bg-gray-700 p-2 rounded-lg transition">
            <X size={24} />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-gray-200">
          <button 
            onClick={() => setActiveTab('file')}
            className={`flex-1 py-4 font-semibold text-sm transition ${activeTab === 'file' ? 'text-blue-600 border-b-2 border-blue-600 bg-blue-50' : 'text-gray-500 hover:bg-gray-50'}`}
          >
            Importar Arquivo (PDF/Excel)
          </button>
          <button 
            onClick={() => setActiveTab('json')}
            className={`flex-1 py-4 font-semibold text-sm transition ${activeTab === 'json' ? 'text-blue-600 border-b-2 border-blue-600 bg-blue-50' : 'text-gray-500 hover:bg-gray-50'}`}
          >
            Dados Brutos (JSON)
          </button>
        </div>

        {/* Content */}
        <div className="p-8 flex-1 overflow-y-auto">
          {status === 'success' ? (
            <div className="text-center py-8 animate-in fade-in zoom-in">
              <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle size={32} />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">Sucesso!</h3>
              <p className="text-gray-600 mb-6">
                O catálogo foi substituído por <strong>{importStats.new}</strong> novos produtos.
              </p>
              <button 
                onClick={onClose}
                className="bg-gray-900 text-white px-6 py-2 rounded-lg hover:bg-gray-800 transition"
              >
                Ver Loja Atualizada
              </button>
              <button 
                onClick={() => { setStatus('idle'); setFile(null); }}
                className="block mx-auto mt-4 text-sm text-blue-600 hover:underline"
              >
                Importar outro arquivo
              </button>
            </div>
          ) : activeTab === 'file' ? (
            <div className="space-y-6">
              <div 
                className={`border-2 border-dashed rounded-xl p-10 text-center transition-colors ${dragActive ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:bg-gray-50'}`}
                onDragEnter={handleDrag}
                onDragLeave={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
              >
                <input 
                  ref={inputRef}
                  type="file" 
                  className="hidden" 
                  accept=".pdf,.xlsx,.xls,.csv"
                  onChange={handleChange}
                />
                
                {!file ? (
                  <>
                    <div className="flex justify-center gap-4 mb-4 text-gray-400">
                      <FileText size={40} />
                      <FileSpreadsheet size={40} />
                    </div>
                    <p className="text-lg font-medium text-gray-700 mb-2">Arraste e solte seu arquivo aqui</p>
                    <p className="text-sm text-gray-500 mb-6">Suporta Planilha Excel (.xlsx) ou PDF do Catálogo</p>
                    <button 
                      onClick={() => inputRef.current?.click()}
                      className="bg-white border border-gray-300 text-gray-700 font-semibold py-2 px-6 rounded-lg hover:bg-gray-50 transition shadow-sm"
                    >
                      Selecionar Arquivo
                    </button>
                  </>
                ) : (
                  <div className="flex flex-col items-center">
                    <div className="bg-blue-100 p-4 rounded-full mb-3 text-blue-600">
                      {file.name.endsWith('.pdf') ? <FileText size={32} /> : <FileSpreadsheet size={32} />}
                    </div>
                    <p className="font-bold text-gray-800">{file.name}</p>
                    <p className="text-sm text-gray-500 mb-4">{(file.size / 1024).toFixed(2)} KB</p>
                    <button onClick={() => setFile(null)} className="text-red-500 text-sm hover:underline">
                      Remover arquivo
                    </button>
                  </div>
                )}
              </div>

              {file && status !== 'processing' && (
                <button 
                  onClick={processFile}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-lg shadow-lg flex items-center justify-center gap-2 transition"
                >
                  <Upload size={20} />
                  {file.name.endsWith('.pdf') ? 'Processar PDF (Simulado)' : 'Ler Planilha e Atualizar'}
                </button>
              )}

              {status === 'processing' && (
                <div className="text-center py-4">
                  <Loader2 className="animate-spin mx-auto text-blue-600 mb-2" size={32} />
                  <p className="text-gray-600">Lendo dados do arquivo...</p>
                </div>
              )}

              {status === 'error' && (
                <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-lg text-sm text-center">
                  Ocorreu um erro ao ler o arquivo. Tente novamente com um formato válido.
                </div>
              )}
              
              <div className="bg-blue-50 border border-blue-100 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2 text-blue-800 font-semibold text-sm">
                  <HelpCircle size={16} />
                  <span>Para Excel (.xlsx), use as colunas:</span>
                </div>
                <div className="flex flex-wrap gap-2 text-xs text-blue-600">
                  <span className="bg-white px-2 py-1 rounded border border-blue-200">Nome</span>
                  <span className="bg-white px-2 py-1 rounded border border-blue-200">Preço</span>
                  <span className="bg-white px-2 py-1 rounded border border-blue-200">Código</span>
                  <span className="bg-white px-2 py-1 rounded border border-blue-200">Cor</span>
                  <span className="bg-white px-2 py-1 rounded border border-blue-200">Estoque</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <p className="text-sm text-gray-600">Cole aqui o array JSON de produtos para atualização direta (modo avançado).</p>
              <textarea 
                value={jsonInput}
                onChange={(e) => setJsonInput(e.target.value)}
                className="w-full h-64 p-4 border border-gray-300 rounded-lg font-mono text-xs focus:ring-2 focus:ring-blue-500 outline-none"
                placeholder='[{"id": "X01", "name": "Nova Planta", "price": 20.0, ...}]'
              />
              <button 
                 onClick={handleJsonSubmit}
                 className="w-full bg-gray-900 text-white font-bold py-3 rounded-lg hover:bg-gray-800 transition"
              >
                Atualizar via JSON
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};