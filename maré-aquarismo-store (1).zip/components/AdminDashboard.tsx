import React, { useState } from 'react';
import { Product, ProductStatus, Coupon } from '../types';
import { Upload, Package, AlertTriangle, TrendingUp, Search, Trash2, Edit, Ticket, Plus } from 'lucide-react';

interface AdminDashboardProps {
  products: Product[];
  coupons: Coupon[];
  searchTerm: string;
  onOpenImport: () => void;
  onDeleteProduct: (id: string) => void;
  onAddCoupon: (c: Coupon) => void;
  onDeleteCoupon: (code: string) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ 
  products, 
  coupons,
  searchTerm, 
  onOpenImport, 
  onDeleteProduct,
  onAddCoupon,
  onDeleteCoupon
}) => {
  const [activeTab, setActiveTab] = useState<'products' | 'coupons'>('products');
  
  // Coupon Form State
  const [newCode, setNewCode] = useState('');
  const [newType, setNewType] = useState<'PERCENTAGE' | 'FIXED'>('PERCENTAGE');
  const [newValue, setNewValue] = useState('');

  // Filter products based on search term
  const filteredProducts = products.filter(p => 
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    p.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (p.barcode && p.barcode.includes(searchTerm)) ||
    (p.internalId && p.internalId.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  // Stats
  const totalProducts = products.length;
  const lowStock = products.filter(p => p.stock && p.stock < 5).length;
  const outOfStock = products.filter(p => p.status === ProductStatus.OUT_OF_STOCK).length;

  const handleAddCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (newCode && newValue) {
        onAddCoupon({
            code: newCode.toUpperCase(),
            type: newType,
            value: parseFloat(newValue),
            active: true
        });
        setNewCode('');
        setNewValue('');
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      
      {/* Header Actions */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Dashboard</h2>
          <p className="text-gray-500 text-sm">Visão geral do estoque e marketing</p>
        </div>
        <div className="flex gap-2">
            <button 
                onClick={() => setActiveTab('products')}
                className={`px-4 py-2 rounded-lg font-medium transition ${activeTab === 'products' ? 'bg-mare-900 text-white shadow-lg' : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'}`}
            >
                Produtos
            </button>
            <button 
                onClick={() => setActiveTab('coupons')}
                className={`px-4 py-2 rounded-lg font-medium transition flex items-center gap-2 ${activeTab === 'coupons' ? 'bg-mare-900 text-white shadow-lg' : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'}`}
            >
                <Ticket size={18} />
                Cupons
            </button>
        </div>
      </div>

      {activeTab === 'products' ? (
        <>
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm flex items-center gap-4">
                <div className="p-3 bg-blue-50 text-blue-600 rounded-lg">
                    <Package size={24} />
                </div>
                <div>
                    <p className="text-sm text-gray-500">Total de Produtos</p>
                    <p className="text-2xl font-bold text-gray-800">{totalProducts}</p>
                </div>
                </div>

                <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm flex items-center gap-4">
                <div className="p-3 bg-orange-50 text-orange-600 rounded-lg">
                    <AlertTriangle size={24} />
                </div>
                <div>
                    <p className="text-sm text-gray-500">Estoque Baixo</p>
                    <p className="text-2xl font-bold text-gray-800">{lowStock}</p>
                </div>
                </div>

                <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm flex items-center gap-4">
                <div className="p-3 bg-red-50 text-red-600 rounded-lg">
                    <TrendingUp size={24} />
                </div>
                <div>
                    <p className="text-sm text-gray-500">Esgotados</p>
                    <p className="text-2xl font-bold text-gray-800">{outOfStock}</p>
                </div>
                </div>
            </div>

            {/* Product Table */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="p-4 border-b border-gray-100 bg-gray-50 flex justify-between items-center">
                <h3 className="font-bold text-gray-700">Inventário de Produtos</h3>
                <div className="flex gap-2">
                    {searchTerm && (
                        <span className="text-xs text-blue-600 bg-blue-50 px-2 py-1 rounded border border-blue-100 self-center">
                        Filtrando por: "{searchTerm}"
                        </span>
                    )}
                    <button 
                        onClick={onOpenImport}
                        className="bg-blue-600 text-white px-3 py-1.5 rounded-lg flex items-center gap-2 hover:bg-blue-700 transition text-sm"
                    >
                        <Upload size={16} />
                        Importar
                    </button>
                </div>
                </div>
                
                <div className="overflow-x-auto">
                <table className="w-full text-left text-xs md:text-sm">
                    <thead className="bg-gray-50 text-gray-600 uppercase text-xs tracking-wider">
                    <tr>
                        <th className="p-3 font-semibold">Produto</th>
                        <th className="p-3 font-semibold">IDs</th>
                        <th className="p-3 font-semibold text-right">Custo</th>
                        <th className="p-3 font-semibold text-right">Venda</th>
                        <th className="p-3 font-semibold text-center">Status</th>
                        <th className="p-3 font-semibold text-center">Estoque</th>
                        <th className="p-3 font-semibold text-right">Ações</th>
                    </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                    {filteredProducts.length > 0 ? (
                        filteredProducts.map(product => (
                        <tr key={product.id} className="hover:bg-gray-50 transition-colors">
                            <td className="p-3 max-w-[200px]">
                            <div className="flex items-center gap-3">
                                <img src={product.image} alt="" className="w-8 h-8 rounded-md object-cover bg-gray-200" />
                                <div>
                                <p className="font-medium text-gray-900 truncate" title={product.name}>{product.name}</p>
                                <p className="text-[10px] text-gray-400">{product.techLevel}</p>
                                </div>
                            </div>
                            </td>
                            <td className="p-3">
                            <div className="flex flex-col text-xs text-gray-500">
                                <span title="Código Principal">Main: <b>{product.id}</b></span>
                                {product.internalId && <span title="Código Interno">Int: {product.internalId}</span>}
                                {product.barcode && <span title="Código de Barras" className="font-mono text-[10px]">{product.barcode}</span>}
                            </div>
                            </td>
                            <td className="p-3 text-right font-mono text-gray-500">
                            {product.costPrice ? `R$ ${product.costPrice.toFixed(2)}` : '-'}
                            </td>
                            <td className="p-3 text-right font-mono font-medium text-gray-900">
                            R$ {product.price.toFixed(2)}
                            </td>
                            <td className="p-3 text-center">
                            <span className={`px-2 py-1 rounded-full text-[10px] font-bold ${
                                product.status === ProductStatus.AVAILABLE ? 'bg-green-100 text-green-700' :
                                product.status === ProductStatus.OUT_OF_STOCK ? 'bg-red-100 text-red-700' :
                                'bg-yellow-100 text-yellow-700'
                            }`}>
                                {product.status}
                            </span>
                            </td>
                            <td className="p-3 text-center font-bold text-gray-700">
                            {product.stock ?? 0}
                            </td>
                            <td className="p-3 text-right">
                            <div className="flex justify-end gap-1">
                                <button className="p-1.5 text-blue-600 hover:bg-blue-50 rounded transition" title="Editar">
                                <Edit size={16} />
                                </button>
                                <button 
                                onClick={() => onDeleteProduct(product.id)}
                                className="p-1.5 text-red-600 hover:bg-red-50 rounded transition" 
                                title="Excluir"
                                >
                                <Trash2 size={16} />
                                </button>
                            </div>
                            </td>
                        </tr>
                        ))
                    ) : (
                        <tr>
                        <td colSpan={7} className="p-8 text-center text-gray-400">
                            Nenhum produto encontrado na busca.
                        </td>
                        </tr>
                    )}
                    </tbody>
                </table>
                </div>
            </div>
        </>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Coupon Form */}
            <div className="md:col-span-1 bg-white p-6 rounded-xl border border-gray-200 shadow-sm h-fit">
                <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
                    <Plus size={18} /> Novo Cupom
                </h3>
                <form onSubmit={handleAddCoupon} className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Código do Cupom</label>
                        <input 
                            type="text" 
                            required
                            value={newCode}
                            onChange={e => setNewCode(e.target.value.toUpperCase())}
                            className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-mare-500 outline-none uppercase"
                            placeholder="EX: PROMO10"
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Tipo de Desconto</label>
                        <select 
                            value={newType}
                            onChange={e => setNewType(e.target.value as any)}
                            className="w-full p-2 border border-gray-300 rounded-lg outline-none"
                        >
                            <option value="PERCENTAGE">Porcentagem (%)</option>
                            <option value="FIXED">Valor Fixo (R$)</option>
                        </select>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Valor</label>
                        <input 
                            type="number" 
                            required
                            min="0"
                            step="0.01"
                            value={newValue}
                            onChange={e => setNewValue(e.target.value)}
                            className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-mare-500 outline-none"
                            placeholder="10"
                        />
                    </div>
                    <button type="submit" className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2 rounded-lg transition">
                        Criar Cupom
                    </button>
                </form>
            </div>

            {/* Coupon List */}
            <div className="md:col-span-2 bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
                <div className="p-4 border-b border-gray-100 bg-gray-50">
                    <h3 className="font-bold text-gray-700">Cupons Ativos</h3>
                </div>
                <div className="divide-y divide-gray-100">
                    {coupons.length > 0 ? coupons.map(coupon => (
                        <div key={coupon.code} className="p-4 flex items-center justify-between hover:bg-gray-50">
                            <div className="flex items-center gap-4">
                                <div className="bg-yellow-100 p-2 rounded text-yellow-700">
                                    <Ticket size={20} />
                                </div>
                                <div>
                                    <p className="font-bold text-gray-800">{coupon.code}</p>
                                    <p className="text-sm text-gray-500">
                                        Desconto: {coupon.type === 'PERCENTAGE' ? `${coupon.value}%` : `R$ ${coupon.value.toFixed(2)}`}
                                    </p>
                                </div>
                            </div>
                            <div className="flex items-center gap-4">
                                <span className={`text-xs px-2 py-1 rounded font-bold ${coupon.active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                                    {coupon.active ? 'ATIVO' : 'INATIVO'}
                                </span>
                                <button 
                                    onClick={() => onDeleteCoupon(coupon.code)}
                                    className="p-2 text-red-500 hover:bg-red-50 rounded transition"
                                    title="Excluir Cupom"
                                >
                                    <Trash2 size={18} />
                                </button>
                            </div>
                        </div>
                    )) : (
                        <div className="p-8 text-center text-gray-400">
                            Nenhum cupom cadastrado.
                        </div>
                    )}
                </div>
            </div>
        </div>
      )}
    </div>
  );
};