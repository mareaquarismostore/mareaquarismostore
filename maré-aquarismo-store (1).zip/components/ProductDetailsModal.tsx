import React from 'react';
import { Product, ProductStatus, TechLevel } from '../types';
import { X, ShoppingCart, Droplets, Ruler, Sun, Tag, Barcode } from 'lucide-react';

interface ProductDetailsModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (product: Product) => void;
}

export const ProductDetailsModal: React.FC<ProductDetailsModalProps> = ({ product, isOpen, onClose, onAddToCart }) => {
  if (!isOpen || !product) return null;

  const isOutOfStock = product.status === ProductStatus.OUT_OF_STOCK;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-4xl overflow-hidden flex flex-col md:flex-row animate-in fade-in zoom-in duration-200">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 bg-white/80 rounded-full hover:bg-white text-gray-600 transition"
        >
          <X size={24} />
        </button>

        {/* Image Section */}
        <div className="w-full md:w-1/2 h-64 md:h-auto relative bg-gray-100">
          <img 
            src={product.image} 
            alt={product.name} 
            className={`w-full h-full object-cover ${isOutOfStock ? 'grayscale opacity-70' : ''}`}
          />
          {isOutOfStock && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/40">
              <span className="bg-red-600 text-white px-6 py-2 text-lg font-bold rounded-full uppercase tracking-wider shadow-lg transform -rotate-12">
                Esgotado
              </span>
            </div>
          )}
        </div>

        {/* Details Section */}
        <div className="w-full md:w-1/2 p-8 flex flex-col">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <span className={`text-xs font-bold px-2 py-1 rounded text-white ${product.techLevel === TechLevel.HIGH ? 'bg-orange-500' : 'bg-green-600'}`}>
                {product.techLevel}
              </span>
              <span className={`text-xs font-bold px-2 py-1 rounded ${
                product.status === ProductStatus.AVAILABLE ? 'bg-green-100 text-green-800' : 
                product.status === ProductStatus.FEW_LEFT ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800'
              }`}>
                {product.status}
              </span>
            </div>

            <h2 className="text-3xl font-bold text-gray-900 mb-2 leading-tight">{product.name}</h2>
            {product.id && <p className="text-sm text-gray-400 font-mono mb-6">Cód: {product.id}</p>}

            <div className="grid grid-cols-2 gap-4 mb-8">
              <div className="bg-gray-50 p-4 rounded-xl border border-gray-100">
                <div className="flex items-center gap-2 text-gray-500 mb-1">
                  <Ruler size={18} />
                  <span className="text-xs uppercase font-bold">Altura</span>
                </div>
                <p className="font-semibold text-gray-800">{product.height}</p>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-xl border border-gray-100">
                <div className="flex items-center gap-2 text-gray-500 mb-1">
                  <Palette size={18} />
                  <span className="text-xs uppercase font-bold">Coloração</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full border border-gray-300" 
                       style={{backgroundColor: product.color.includes('Vermelh') ? '#ef4444' : product.color.includes('Rox') ? '#9333ea' : product.color.includes('Rosa') ? '#ec4899' : '#22c55e'}}>
                  </div>
                  <p className="font-semibold text-gray-800">{product.color}</p>
                </div>
              </div>

              {product.stock !== undefined && (
                <div className="bg-gray-50 p-4 rounded-xl border border-gray-100">
                  <div className="flex items-center gap-2 text-gray-500 mb-1">
                    <Tag size={18} />
                    <span className="text-xs uppercase font-bold">Estoque</span>
                  </div>
                  <p className="font-semibold text-gray-800">{product.stock} unidades</p>
                </div>
              )}
            </div>
          </div>

          <div className="mt-auto pt-6 border-t border-gray-100 flex items-center justify-between gap-4">
            <div>
              <p className="text-sm text-gray-500">Preço Unitário</p>
              <p className="text-3xl font-bold text-mare-900">R$ {product.price.toFixed(2).replace('.', ',')}</p>
            </div>

            <button
              onClick={() => {
                onAddToCart(product);
                onClose();
              }}
              disabled={isOutOfStock}
              className={`flex-1 py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-2 transition transform active:scale-95 ${
                isOutOfStock 
                  ? 'bg-gray-200 text-gray-400 cursor-not-allowed' 
                  : 'bg-mare-900 text-white hover:bg-mare-800 shadow-lg hover:shadow-xl'
              }`}
            >
              <ShoppingCart size={24} />
              {isOutOfStock ? 'Indisponível' : 'Adicionar ao Carrinho'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const Palette = ({ size, className }: { size?: number, className?: string }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    width={size} 
    height={size} 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className={className}
  >
    <circle cx="13.5" cy="6.5" r=".5" fill="currentColor"></circle>
    <circle cx="17.5" cy="10.5" r=".5" fill="currentColor"></circle>
    <circle cx="8.5" cy="7.5" r=".5" fill="currentColor"></circle>
    <circle cx="6.5" cy="12.5" r=".5" fill="currentColor"></circle>
    <path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z"></path>
  </svg>
);