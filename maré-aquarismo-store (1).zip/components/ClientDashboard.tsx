import React from 'react';
import { Order, OrderStatus, User } from '../types';
import { Package, Calendar, ChevronRight, ShoppingBag, Search } from 'lucide-react';

interface ClientDashboardProps {
  user: User;
  orders: Order[];
  searchTerm: string;
}

export const ClientDashboard: React.FC<ClientDashboardProps> = ({ user, orders, searchTerm }) => {
  const filteredOrders = orders.filter(order => {
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    // Search by Order ID or Product Name inside order
    return (
      order.id.toLowerCase().includes(term) ||
      order.items.some(item => item.name.toLowerCase().includes(term))
    );
  });

  return (
    <div className="container mx-auto max-w-4xl animate-in fade-in duration-500">
      <div className="mb-8 p-6 bg-gradient-to-r from-mare-900 to-mare-800 rounded-2xl text-white shadow-lg">
        <h2 className="text-3xl font-bold mb-2">Olá, {user.name}</h2>
        <p className="text-blue-200">Bem-vindo à sua área do cliente. Aqui você pode acompanhar seus pedidos.</p>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="p-6 border-b border-gray-100 flex justify-between items-center">
          <h3 className="text-xl font-bold text-gray-800 flex items-center gap-2">
            <Package className="text-mare-500" />
            Histórico de Pedidos
          </h3>
          {searchTerm && (
            <span className="text-sm text-gray-500 bg-gray-100 px-3 py-1 rounded-full flex items-center gap-1">
              <Search size={14} />
              Filtrando por: "{searchTerm}"
            </span>
          )}
        </div>

        {filteredOrders.length === 0 ? (
          <div className="p-12 text-center">
            <div className="w-16 h-16 bg-gray-100 text-gray-400 rounded-full flex items-center justify-center mx-auto mb-4">
              <ShoppingBag size={32} />
            </div>
            <h4 className="text-lg font-medium text-gray-600">Nenhum pedido encontrado</h4>
            <p className="text-gray-400 text-sm mt-1">
              {searchTerm ? 'Nenhum pedido corresponde à sua busca.' : 'Você ainda não fez nenhuma compra conosco.'}
            </p>
          </div>
        ) : (
          <div className="divide-y divide-gray-100">
            {filteredOrders.map(order => (
              <div key={order.id} className="p-6 hover:bg-gray-50 transition-colors group cursor-pointer">
                <div className="flex flex-col md:flex-row justify-between md:items-center gap-4 mb-4">
                  <div className="flex items-center gap-4">
                    <div className="bg-blue-50 p-3 rounded-lg text-mare-600 font-bold text-lg">
                      #{order.id}
                    </div>
                    <div>
                      <div className="flex items-center gap-2 text-sm text-gray-500 mb-1">
                        <Calendar size={14} />
                        {order.date}
                      </div>
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        order.status === OrderStatus.PAID ? 'bg-green-100 text-green-800' :
                        order.status === OrderStatus.PENDING ? 'bg-yellow-100 text-yellow-800' :
                        'bg-blue-100 text-blue-800'
                      }`}>
                        {order.status}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between md:justify-end gap-6 flex-1">
                     <div className="text-right">
                        <p className="text-xs text-gray-500">Total do Pedido</p>
                        <p className="text-lg font-bold text-gray-900">R$ {order.total.toFixed(2).replace('.', ',')}</p>
                     </div>
                     <ChevronRight className="text-gray-300 group-hover:text-mare-500 transition-colors" />
                  </div>
                </div>
                
                {/* Order Preview Items */}
                <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
                  {order.items.map((item, idx) => (
                    <div key={idx} className="flex-shrink-0 w-16 h-16 rounded-md border border-gray-200 overflow-hidden relative" title={`${item.quantity}x ${item.name}`}>
                      <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                      <span className="absolute bottom-0 right-0 bg-black/60 text-white text-[10px] px-1 font-bold">
                        x{item.quantity}
                      </span>
                    </div>
                  ))}
                  {order.items.length > 5 && (
                     <div className="flex-shrink-0 w-16 h-16 rounded-md border border-gray-200 bg-gray-50 flex items-center justify-center text-xs text-gray-500 font-medium">
                        +{order.items.length - 5}
                     </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};